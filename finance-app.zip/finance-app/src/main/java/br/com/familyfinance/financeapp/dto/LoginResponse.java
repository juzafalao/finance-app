// src/main/java/br/com/familyfinance/financeapp/dto/LoginResponse.java
package br.com.familyfinance.financeapp.dto;

import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {
    private String token;
}
