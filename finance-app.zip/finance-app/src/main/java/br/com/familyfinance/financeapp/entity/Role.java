package br.com.familyfinance.financeapp.entity;

public enum Role {
    ADMIN, USER
}
