package br.com.familyfinance.financeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
